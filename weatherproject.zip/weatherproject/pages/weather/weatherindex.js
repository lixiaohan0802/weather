// pages/weather/weatherindex.js
var utils = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    today: '',
    // search
    inputCity: '北京',
    city: '',
    district: '',
    street: '',
    weather: {},

  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      //  更新当前日期
      today: utils.formatTime(new Date()).split(' ')[0]

    });
    var self = this;
    wx.getLocation({
      success: function(res) {
        console.log(res),
          self.getCity(res.latitude, res.longitude)
      },
    })
  },
  getCity: function(lat, lng) {
    var url = "https://api.map.baidu.com/geocoder/v2/";
    var param = {
      location: lat + "," + lng,
      output: "json", //返回的数据格式
      ak: "ofqO5GqWgSOK0OjqIoOnbaoWiBh8zOoK" //地图api的ak
    };
    var that = this;
    //发出请求获取数据
    wx.request({
      url: url,
      data: param,
      success: function(res) {
        console.log(res);
        var city = res.data.result.addressComponent.city;
        var district = res.data.result.addressComponent.district;
        var street = res.data.result.addressComponent.street;
        that.setData({
          city: city,
          district: district,
          street: street
        });
        //调用自定义的函数获取天气信息
        city = city.substring(0, city.length - 1); //截掉最后一个字"市"
        that.getWeather(city);
      }
    })
  },
  getWeather: function(city) {
    var that = this;
    wx.request({
      url: 'https://wthrcdn.etouch.cn/weather_mini?city=' + city,
      data: {},
      success: function(res) {
        console.log(res);
        if (res.data.status == 1002) {
          wx.showModal({
            title: '提示',
            content: '输入的城市名称有误，请重新输入！',
            showCancel: false,
            success: function(res) {
              that.setData({
                inputCity: ""
              })
            }
          })
        } else {
          var weatherObj = res.data.data;
          for (var i = 0; i < weatherObj.forecast.length; i++) {
            var d = weatherObj.forecast[i].date;
            var dfl = weatherObj.forecast[i].fengli;
            weatherObj.forecast[i].data = ' ' + d.replace('星期', ' 星期');
            weatherObj.forecast[i].fengli = dfl.replace('<![CDATA[', '').replace(']]>', '');
          }
          weatherObj.yesterday.fl = weatherObj.yesterday.fl.replace('<![CDATA[', '').replace(']]>', '');

          that.setData({
            weather: weatherObj,
            inputCity: ''
          })

        }
      }
    })
  },
  bindSearch: function(e) {
    this.setData({
      city: this.data.inputCity
    })
    this.getWeather(this.data.inputCity)
    
  },
  inputing: function(e) {
    this.setData({
      inputCity: e.detail.value
    })
  }


})